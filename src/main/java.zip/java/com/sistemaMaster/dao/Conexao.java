package com.sistemaMaster.dao;

import java.sql.*;

public class Conexao implements AutoCloseable {
    private final String URL = "jdbc:sqlite:" + System.getProperty("user.dir") + 
                              java.io.File.separator + "dbsistemavendas.db"; 
    private Connection conexao;

    public Conexao() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
            conexao = DriverManager.getConnection(URL);
            conexao.setAutoCommit(false);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver SQLite não encontrado", e);
        }
    }

    public Connection getConexao() {
        return conexao;
    }

    public void confirmar() throws SQLException {
        try {
            conexao.commit();
        } catch (SQLException e) {
            rollback();
            throw new SQLException("Erro ao confirmar transação", e);
        }
    }

    public void rollback() {
        try {
            if (conexao != null && !conexao.isClosed()) {
                conexao.rollback();
            }
        } catch (SQLException e) {
            System.err.println("Erro ao fazer rollback: " + e.getMessage());
        }
    }

    @Override
    public void close() throws SQLException {
        if (conexao != null && !conexao.isClosed()) {
            try {
                if (!conexao.getAutoCommit()) {
                    conexao.commit(); // Confirma pendências antes de fechar
                }
                conexao.close();
            } catch (SQLException e) {
                throw new SQLException("Erro ao fechar conexão", e);
            }
        }
    }
}
package com.sistemaMaster.gui;

import com.sistemaMaster.dao.FechamentoDAO;
import com.sistemaMaster.to.FechamentoDia;
import com.sistemaMaster.auxiliar.PDFGenerator;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Fechamento extends JFrame {

    private JLabel lblTitulo, lblData, lblVendas, lblServicos, lblLucro, lblCaixa;
    private JLabel lblDinheiro, lblDebito, lblCredito, lblPix;
    private JButton btnGerarPDF, btnHistorico, btnSalvarFechamento;
    private JPanel painelPrincipal, painelDetalhes, painelHistorico;
    private CardLayout cardLayout;
    private JTable tabelaHistorico;
    private JScrollPane scrollHistorico;

    // Dados do fechamento atual
    private FechamentoDia fechamentoAtual;
    private FechamentoDAO fechamentoDAO;

    public Fechamento() {
        setTitle("Fechamento de Caixa - Oficina Mecânica");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        fechamentoDAO = new FechamentoDAO();

        cardLayout = new CardLayout();
        JPanel painelCards = new JPanel(cardLayout);

        painelPrincipal = criarPainelFechamento();
        painelHistorico = criarPainelHistorico();

        painelCards.add(painelPrincipal, "fechamento");
        painelCards.add(painelHistorico, "historico");

        add(painelCards);
        setVisible(true);
    }

    private JPanel criarPainelFechamento() {
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setBackground(new Color(245, 245, 245));
        painel.setBorder(new EmptyBorder(30, 40, 30, 40));

        calcularDadosFechamento();

        String dataHoje = new SimpleDateFormat("dd/MM/yyyy").format(new Date());

        lblTitulo = criarLabel("Fechamento do Dia", 28, Font.BOLD, new Color(33, 150, 243));
        lblData = criarLabel("Data: " + dataHoje, 18, Font.BOLD, Color.DARK_GRAY);
        lblVendas = criarLabel("Total de Vendas: R$ " + String.format("%.2f", fechamentoAtual.getTotalVendas()), 16,
                Font.PLAIN, Color.BLACK);
        lblServicos = criarLabel("Vendas Realizadas: " + fechamentoAtual.getTotalServicos(), 16, Font.PLAIN,
                Color.BLACK);
        lblLucro = criarLabel("Lucro Bruto: R$ " + String.format("%.2f", fechamentoAtual.getLucroBruto()), 16,
                Font.PLAIN, new Color(76, 175, 80));
        lblCaixa = criarLabel("Total em Caixa: R$ " + String.format("%.2f", fechamentoAtual.getTotalCaixa()), 18,
                Font.BOLD, new Color(255, 152, 0));

        painelDetalhes = new JPanel();
        painelDetalhes.setLayout(new GridLayout(2, 2, 20, 15));
        painelDetalhes.setBackground(new Color(245, 245, 245));
        painelDetalhes.setMaximumSize(new Dimension(700, 100));

        lblDinheiro = criarLabelDetalhes("💵 Dinheiro", fechamentoAtual.getTotalDinheiro(), new Color(76, 175, 80));
        lblDebito = criarLabelDetalhes("💳 Débito", fechamentoAtual.getTotalDebito(), new Color(33, 150, 243));
        lblCredito = criarLabelDetalhes("💳 Crédito", fechamentoAtual.getTotalCredito(), new Color(255, 152, 0));
        lblPix = criarLabelDetalhes("📱 PIX", fechamentoAtual.getTotalPix(), new Color(156, 39, 176));

        painelDetalhes.add(lblDinheiro);
        painelDetalhes.add(lblDebito);
        painelDetalhes.add(lblCredito);
        painelDetalhes.add(lblPix);

        // Botões
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        painelBotoes.setBackground(new Color(245, 245, 245));

        btnSalvarFechamento = criarBotao("Salvar Fechamento", new Color(76, 175, 80), Color.WHITE);
        btnSalvarFechamento.addActionListener(e -> salvarFechamento());

        btnGerarPDF = criarBotao("Gerar PDF", new Color(255, 152, 0), Color.WHITE);
        btnGerarPDF.addActionListener(e -> gerarPDF());

        btnHistorico = criarBotao("Histórico", new Color(33, 150, 243), Color.WHITE);
        btnHistorico.addActionListener(e -> {
            atualizarHistorico();
            cardLayout.show((Container) getContentPane().getComponent(0), "historico");
        });

        painelBotoes.add(btnSalvarFechamento);
        painelBotoes.add(btnGerarPDF);
        painelBotoes.add(btnHistorico);

        painel.add(lblTitulo);
        painel.add(Box.createRigidArea(new Dimension(0, 10)));
        painel.add(lblData);
        painel.add(Box.createRigidArea(new Dimension(0, 15)));
        painel.add(lblVendas);
        painel.add(lblServicos);
        painel.add(lblLucro);
        painel.add(lblCaixa);
        painel.add(Box.createRigidArea(new Dimension(0, 25)));
        painel.add(painelDetalhes);
        painel.add(Box.createRigidArea(new Dimension(0, 30)));
        painel.add(painelBotoes);

        return painel;
    }

    private JPanel criarPainelHistorico() {
        JPanel painel = new JPanel();
        painel.setLayout(new BorderLayout());
        painel.setBackground(new Color(245, 245, 245));
        painel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel lblHist = criarLabel("Histórico de Fechamentos", 24, Font.BOLD, new Color(33, 150, 243));
        lblHist.setHorizontalAlignment(SwingConstants.CENTER);
        painel.add(lblHist, BorderLayout.NORTH);

        // Tabela
        String[] colunas = { "Data", "Vendas (R$)", "Dinheiro (R$)", "Débito (R$)", "Crédito (R$)", "PIX (R$)",
                "Lucro (R$)", "Serviços" };
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabelaHistorico = new JTable(modelo);
        tabelaHistorico.setFont(new Font("Arial", Font.PLAIN, 12));
        tabelaHistorico.setRowHeight(30);
        tabelaHistorico.setBackground(Color.WHITE);
        tabelaHistorico.setSelectionBackground(new Color(33, 150, 243, 50));
        tabelaHistorico.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        tabelaHistorico.getTableHeader().setBackground(new Color(33, 150, 243));
        tabelaHistorico.getTableHeader().setForeground(Color.WHITE);

        scrollHistorico = new JScrollPane(tabelaHistorico);
        scrollHistorico.setBackground(Color.WHITE);
        painel.add(scrollHistorico, BorderLayout.CENTER);

        JButton btnVoltar = criarBotao("Voltar", new Color(108, 117, 125), Color.WHITE);
        btnVoltar.addActionListener(e -> cardLayout.show((Container) getContentPane().getComponent(0), "fechamento"));

        JPanel painelSul = new JPanel();
        painelSul.setBackground(new Color(245, 245, 245));
        painelSul.add(btnVoltar);

        painel.add(painelSul, BorderLayout.SOUTH);

        return painel;
    }

    private void calcularDadosFechamento() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        long inicioDoDia = calendar.getTimeInMillis();

        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        long fimDoDia = calendar.getTimeInMillis();
        Date dataFechamento = new Date(fimDoDia);

        double totalVendas = 0, totalDinheiro = 0, totalDebito = 0, totalCredito = 0, totalPix = 0, lucro = 0;
        int totalServicos = 0;

        try {
            com.sistemaMaster.dao.Conexao c = new com.sistemaMaster.dao.Conexao();
            String sql = "SELECT v.CODIGO, v.VALORTOTALPRODUTO, v.FORMA_PAGAMENTO, iv.QUANTIDADE, iv.VALORUNITARIO, p.PRECOVENDA, p.PRECOCOMPRA "
                    +
                    "FROM TBVENDA v " +
                    "JOIN TBITEMVENDA iv ON v.CODIGO = iv.CODIGOVENDA " +
                    "JOIN TBPRODUTO p ON iv.CODIGOPRODUTO = p.CODIGO " +
                    "WHERE v.DATAVENDA BETWEEN ? AND ? AND v.SITUACAO = 2";

            java.sql.PreparedStatement ps = c.getConexao().prepareStatement(sql);
            ps.setLong(1, inicioDoDia);
            ps.setLong(2, fimDoDia);
            java.sql.ResultSet rs = ps.executeQuery();

            Set<Integer> vendasContadas = new HashSet<>();
            while (rs.next()) {
                int forma = rs.getInt("FORMA_PAGAMENTO");
                double valorVenda = rs.getDouble("VALORUNITARIO") * rs.getInt("QUANTIDADE");
                int quantidade = rs.getInt("QUANTIDADE");
                double precoVenda = rs.getDouble("PRECOVENDA");
                double precoCompra = rs.getDouble("PRECOCOMPRA");
                int codigoVenda = rs.getInt("CODIGO");

                // Soma apenas uma vez por venda para os totais por forma de pagamento
                if (!vendasContadas.contains(codigoVenda)) {
                    totalVendas += valorVenda;
                    vendasContadas.add(codigoVenda);
                    switch (forma) {
                        case 1:
                            totalDinheiro += valorVenda;
                            break;
                        case 2:
                            totalDebito += valorVenda;
                            break;
                        case 3:
                            totalCredito += valorVenda;
                            break;
                        case 4:
                            totalPix += valorVenda;
                            break;
                    }
                }
                // Lucro bruto por item vendido
                lucro += (precoVenda - precoCompra) * quantidade;
                totalServicos++;
            }
            c.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao buscar vendas do dia: " + ex.getMessage());
        }

        fechamentoAtual = new FechamentoDia(dataFechamento, totalVendas, totalDinheiro, totalDebito, totalCredito, totalPix,
                lucro, totalServicos);
    }

    private void salvarFechamento() {
        try {
            // Verifica se já existe fechamento para hoje
            FechamentoDia existente = fechamentoDAO.recuperarPorData(fechamentoAtual.getDataFechamento());
            if (existente != null) {
                int opcao = JOptionPane.showConfirmDialog(this,
                        "Já existe um fechamento para hoje.\nDeseja substituí-lo?",
                        "Fechamento Existente",
                        JOptionPane.YES_NO_OPTION);
                if (opcao != JOptionPane.YES_OPTION) {
                    return;
                }
            }

            fechamentoDAO.inserir(fechamentoAtual);
            JOptionPane.showMessageDialog(this,
                    "Fechamento salvo com sucesso!",
                    "Sucesso",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao salvar fechamento: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void gerarPDF() {
        try {
            File diretorio = new File("relatorios");
            if (!diretorio.exists()) {
                diretorio.mkdirs();
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            String nomeArquivo = "Fechamento_" + sdf.format(fechamentoAtual.getDataFechamento()) + ".pdf";
            String caminhoCompleto = diretorio.getAbsolutePath() + File.separator + nomeArquivo;

            SimpleDateFormat sdfBr = new SimpleDateFormat("dd/MM/yyyy");
            PDFGenerator.gerarFechamentoPDF(
                    sdfBr.format(fechamentoAtual.getDataFechamento()),
                    fechamentoAtual.getTotalVendas(),
                    fechamentoAtual.getTotalDinheiro(),
                    fechamentoAtual.getTotalDebito(),
                    fechamentoAtual.getTotalCredito(),
                    fechamentoAtual.getTotalPix(),
                    fechamentoAtual.getLucroBruto(),
                    fechamentoAtual.getTotalServicos(),
                    caminhoCompleto);

            int opcao = JOptionPane.showConfirmDialog(this,
                    "PDF gerado com sucesso!\n\n" +
                            "Arquivo: " + nomeArquivo + "\n" +
                            "Local: " + diretorio.getAbsolutePath() + "\n\n" +
                            "Deseja abrir o arquivo agora?",
                    "PDF Gerado",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE);

            if (opcao == JOptionPane.YES_OPTION) {
                try {
                    Desktop.getDesktop().open(new File(caminhoCompleto));
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this,
                            "Não foi possível abrir o arquivo automaticamente.\n" +
                                    "Você pode encontrá-lo em: " + caminhoCompleto,
                            "Aviso",
                            JOptionPane.WARNING_MESSAGE);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao gerar PDF: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void atualizarHistorico() {
        try {
            ArrayList<FechamentoDia> fechamentos = fechamentoDAO.listarTodos();
            DefaultTableModel modelo = (DefaultTableModel) tabelaHistorico.getModel();
            modelo.setRowCount(0);

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            for (FechamentoDia f : fechamentos) {
                Object[] linha = {
                        sdf.format(f.getDataFechamento()),
                        String.format("%.2f", f.getTotalVendas()),
                        String.format("%.2f", f.getTotalDinheiro()),
                        String.format("%.2f", f.getTotalDebito()),
                        String.format("%.2f", f.getTotalCredito()),
                        String.format("%.2f", f.getTotalPix()),
                        String.format("%.2f", f.getLucroBruto()),
                        f.getTotalServicos()
                };
                modelo.addRow(linha);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar histórico: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private JLabel criarLabel(String texto, int tamanho, int estilo, Color cor) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", estilo, tamanho));
        label.setForeground(cor);
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    private JLabel criarLabelDetalhes(String texto, double valor, Color cor) {
        JLabel label = new JLabel("<html><div style='text-align: center;'>" + texto + "<br><b>R$ "
                + String.format("%.2f", valor) + "</b></div></html>");
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        label.setForeground(cor);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(cor, 2),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        label.setOpaque(true);
        label.setBackground(Color.WHITE);
        return label;
    }

    private JButton criarBotao(String texto, Color corFundo, Color corTexto) {
        JButton botao = new JButton(texto);
        botao.setFocusPainted(false);
        botao.setBackground(corFundo);
        botao.setForeground(corTexto);
        botao.setFont(new Font("Arial", Font.BOLD, 14));
        botao.setPreferredSize(new Dimension(150, 40));
        botao.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return botao;
    }

    public static void mostrarFechamento() {
        SwingUtilities.invokeLater(() -> {
            new Fechamento();
        });
    }
}
